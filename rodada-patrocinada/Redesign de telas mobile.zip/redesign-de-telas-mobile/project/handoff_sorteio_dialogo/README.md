# Handoff: RetroFoot98 — Sorteio & Diálogo de saída (Desktop + Mobile)

## Visão geral
Redesign de **2 telas**, num arquivo (`Sorteio e Dialogo.dc.html`):
1. **Sorteio dos jogos da Copa do Brasil** — tela base com duas listas.
2. **Sair para o menu** — modal de confirmação (gravar/sair) sobre a tela.

Mesmas diretrizes das telas já entregues: header/footer fixos, logo só 18×18 na
barra de título, ações organizadas, mobile no breakpoint 760px.

## Sobre os arquivos
Os `.dc.html` são **referências de design em HTML** — protótipos, não código de
produção. Recrie no código real (`Elifoot/public/index.html`) usando as
**classes/tokens existentes** (`.cl-*`, `var(--felt)`, `var(--navy)`, etc.). Os
protótipos usam estilos inline e classes `rf-*` — **traduza**, não cole o CSS.

## Fidelidade
**Alta fidelidade.** Cores, tipografia, espaçamento e interações finais.

## Shell (idêntico às telas logadas já entregues)
Barra de título navy (logo 18×18 + "RetroFoot98" + `_ □ ✕`); nav `Início · Sobre
nós · Como jogar · Contato` + chip "100% Online" + `👤 LEANDRO TESTE` + **Sair**;
footer padrão. Bevel 2px, cantos quadrados, grafia "Selecção/Seleccionar".

## Telas

### 1. Sorteio dos jogos da Copa do Brasil
- **Cabeçalho de etapa** (46px): à esquerda o selo da competição (logo/troféu
  20px) + "Copa do Brasil"; ao centro o título "Sorteio dos jogos da Copa do
  Brasil".
- **Duas listas lado a lado** (ocupam a altura, rolam internamente), cada uma
  numa caixa branca com bevel afundado e **cabeçalho navy**:
  - **Times** — lista alfabética de clubes (ABC, ÁGUIA DE MARABÁ, AMAZONAS…),
    linhas com hairline `#ececec`.
  - **Sorteados** — clubes já sorteados em **bold navy** + status mono verde
    (ex.: "CORINTHIANS — ISENTO").
- **Barra de ação** (centralizada): botão **⏩ Acelerar sorteio**.
- Observação: no original o título ficava numa faixa navy com selo "orelha"
  saindo pra fora; aqui o selo entra no cabeçalho de etapa padronizado.

### 2. Sair para o menu (modal)
Abre ao clicar **Sair** (ou sair pra o menu). Backdrop escuro (`rgba(0,0,0,.45)`)
cobre a tela; **janela modal** centralizada com bevel + sombra:
- **Barra de título navy** "Sair para o menu" com botão minimizar `_` à esquerda.
- **Corpo chrome:** texto centralizado "Quer gravar o jogo antes de sair? O
  progresso não gravado será perdido."
- **Dois botões grandes** lado a lado (bevel, emoji acima do label): **☁ Gravar
  e sair** (nuvem verde) e **✖ Sair sem gravar** (X vermelho).
- Abaixo, botão menor **Cancelar** (fecha o modal).
- Fecha ao clicar no backdrop, no `_` ou em Cancelar.

## Comportamento
- Modal controlado por estado `modal` (abre no Sair, fecha em backdrop/`_`/
  Cancelar). "Gravar e sair" / "Sair sem gravar" levam ao fluxo real de saída.
- Listas rolam de forma independente. "Acelerar sorteio" avança a animação do
  sorteio (lógica existente do jogo).
- Chip online pisca ~1.6s.

## Responsivo (breakpoint 760px)
Desktop: janela 1100×632 centralizada, escalada por JS. Abaixo de 760px: janela
largura cheia (sem scale/sombra), título sticky, nav faz wrap, chip online some.
As duas listas do sorteio **empilham** (cada uma com altura limitada e scroll).
No modal, os dois botões grandes empilham; modal vira `position:fixed`.

## Design tokens
`--felt #2f8f2f`, `--navy #000080`, `--chrome #c0c0c0`, `--yellow #ffff00`,
`--success #1a8f3c` (gravar), `--danger #cc0000` (sair/X). Bevel 2px (claro
`#fff`, escuro `#808080`/`#707070`; inverte no `:active`); listas = bevel
afundado. Type: stacks de sistema; mono pra status ("ISENTO")/números; bold 700–800.

## Assets
`assets/logo.webp` (18×18 na barra de título; 20px como selo da competição — no
jogo real, usar o troféu da competição de `assets/trofeu-*`). Ícones = emoji.

## Arquivos neste pacote
- `Sorteio e Dialogo.dc.html` — as 2 telas + mobile (referência principal).
- `Home.dc.html` — referência do shell.

## Onde aplicar
`Elifoot/public/index.html`. Reimplementar com classes `.cl-*` e tokens
existentes. **Não alterar lógica de jogo/back-end** — só markup, estilos e a
apresentação do sorteio/modal.
