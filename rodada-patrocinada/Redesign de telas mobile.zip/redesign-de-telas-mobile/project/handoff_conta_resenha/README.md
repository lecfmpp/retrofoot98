# Handoff: RetroFoot98 — Conta & Modo Resenha (Desktop + Mobile)

## Visão geral
Redesign de **6 telas** num fluxo navegável (`Conta e Resenha.dc.html`):
Entrar (login) → Criar conta → Modo Resenha → Abrir sala → Entrar numa Resenha
→ Sala (lobby).

Objetivos: header/footer fixos em todas as telas (inclusive login/criar conta),
sem logo gigante (só 18×18 na barra de título), Voltar sempre no mesmo lugar,
botões numa barra de ação inferior organizada, e telas densas (lobby) em colunas.

## Sobre os arquivos
Os `.dc.html` são **referências de design em HTML** — protótipos de look &
comportamento, não código de produção. Recrie no código real
(`Elifoot/public/index.html`) usando as **classes/tokens existentes** (`.cl-*`,
`var(--felt)`, `var(--navy)`, etc.). Os protótipos usam estilos inline e classes
`rf-*` próprias — **traduza** pro vocabulário real, não cole o CSS.

## Fidelidade
**Alta fidelidade.** Cores, tipografia, espaçamento e interações finais.

## Shell compartilhado (todas as telas)
- **Barra de título** navy: logo 18×18 + "RetroFoot98" + `_ □ ✕`.
- **Nav**: `Início · Sobre nós · Como jogar · Contato`. Público (login/criar
  conta): botão **🔑 Entrar** à direita. Logado: chip "100% Online" +
  `👤 LEANDRO TESTE` + **Sair**.
- **Cabeçalho de etapa** (46px, `rgba(0,0,0,.16)`): `‹ Voltar` esq, título
  centralizado (uppercase, tracking), pill mono à direita quando há código.
- **Barra de ação inferior** (≥56px): primária verde à direita; hints/secundárias
  à esquerda.
- **Footer**: `v2026.01 · © 2026 RetroFoot98` | `Sobre nós · Contato · Termos ·
  Privacidade`. Corpo felt green full-bleed.
- Bevel 2px (inverte no `:active`), cantos quadrados exceto pills/choice cards,
  grafia **"Selecção/Seleccionar"** com cç.

## Telas

### 1. Entrar / Login (público)
Card ~440px. **Tabs segmentadas**: `Já tenho conta` (ativa, amarela) / `Criar
conta nova`. Subtítulo "Entre pra acessar seus jogos salvos na nuvem." Campos
**E-mail**, **Senha** (link `Esqueci minha senha` à direita do label). CTA
**✔ Entrar** → Modo Resenha (logado). Tab ativa = fundo amarelo/texto navy;
inativa = verde escuro/texto claro; caixa bevel afundada.

### 2. Criar conta (público)
Mesmo card, tab `Criar conta nova` ativa. Subtítulo "Crie sua conta pra salvar
seus jogos na nuvem e continuar em qualquer aparelho." Campos **Nome de
treinador**, **E-mail**, **Senha** + nota "Pelo menos 6 caracteres. Evite senhas
óbvias…". CTA **✔ Criar conta** → Modo Resenha.

### 3. Modo Resenha (logado)
Título serif "O que você quer fazer?" + 2 choice cards: 🏟️ **Criar nova Resenha**
("Você vira o anfitrião e convida os amigos com um código.") e 🔑 **Entrar numa
Resenha** ("Já tem o código de um amigo? Entre na Resenha dele."). Link amarelo
"↻ Você já joga 1 Resenha — toque pra reentrar" → lobby.

### 4. Abrir sala (logado)
Campo **Nome da sala** + nota "Cada jogador escolhe o próprio time ao entrar,
entre os clubes ainda controlados pela CPU." CTA **✔ Abrir** (desabilitado até
ter nome) → lobby.

### 5. Entrar numa Resenha (logado)
Subtítulo "Digite o código que o anfitrião te passou." Campo **Código da
Resenha** (mono uppercase, maxlength 6, letter-spacing 4px). CTA **✔ Entrar**
(habilita com ≥4 chars) → lobby.

### 6. Sala / Lobby (logado)
Cabeçalho: `‹ Sair da sala` · "SALA · TESTE" · pill `Código S9RJH`. **Duas
colunas** (rolam internamente):
- **Esquerda:** painel **Convidar treinadores** (grid 2 col: 🟢 WhatsApp com
  prefixo `+55` + "DDD + número" + Enviar; ✉ e-mail + Enviar; abaixo "Link da
  sala: retrofoot98.com.br/?sala=S9RJH"); painel **🔍 Convidar quem já tem conta**
  (busca "mín. 3 letras"); **Participantes (1)** (bolinha verde + "LEANDRO TESTE
  _(anfitrião)_" + "Confirmado" + select "Escolher time…").
- **Direita:** painel **Partida** ("🎲 Sortear times" + "Velocidade do jogo"
  toggles `1x 1.5x 2x 3x 5x`, selecionado navy/branco); painel **💬 Chat da sala**
  ("Nenhuma mensagem ainda. Diga oi! 👋" + campo + Enviar).
- **Ação:** hint "Mínimo de 2 treinadores pra começar." (esq); `✖ Sair` +
  `✔ Começar` (verde, desabilitado <2 jogadores) (dir).

## Comportamento & navegação
- `view` controla a tela; Voltar retrocede (1ª tela → Home). Shell alterna
  público/logado conforme a view.
- Validação: nome da sala não-vazio; código alfanumérico ≤6 (CTA habilita ≥4).
- Toggle de velocidade: seleção única (navy). Chip online pisca ~1.6s. Transições
  só em hover.

## Responsivo (breakpoint 760px)
Desktop: janela 1100×632 centralizada no felt, escalada por JS (`transform:
scale`). Abaixo de 760px: janela **largura cheia** (sem scale/sombra), título
sticky, nav faz wrap, chip online some, choice cards e colunas do lobby
**empilham**, grid de convites vira 1 coluna, barra de ação faz wrap.

## Design tokens
`--felt #2f8f2f`, `--navy #000080`, `--chrome #c0c0c0`, `--yellow #ffff00`,
`--success #1a8f3c`, `--danger #cc0000`. Bevel 2px (claro `#fff`, escuro
`#808080`/`#707070`). Radius só em pills (12/999px) e choice cards (12px).
Type: stacks de sistema; Georgia itálico decorativo; mono pra números/códigos;
bold 700–800 carrega a hierarquia.

## Assets
`assets/logo.webp` (usada 18×18 na barra de título). Ícones = emoji nativos —
não criar SVG/icon font.

## Arquivos neste pacote
- `Conta e Resenha.dc.html` — as 6 telas + mobile (referência principal).
- `Home.dc.html` — referência do shell (header/nav/footer).

## Onde aplicar
`Elifoot/public/index.html`. Reimplementar com classes `.cl-*` e tokens
existentes. **Não alterar lógica de jogo/back-end** — só markup, estilos e
navegação.
