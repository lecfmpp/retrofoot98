# Handoff: RetroFoot98 — Setup do Jogo (Desktop + Mobile)

## Visão geral
Redesign de **4 telas** do setup pós-lobby, num fluxo navegável
(`Setup do Jogo.dc.html`):
Dinheiro (moeda) → Jogadores (nomes) → Escolha os clubes → A iniciar o jogo (loading).

Mesmas diretrizes das outras telas já entregues: header/footer fixos, logo só
18×18 na barra de título (sem logo gigante centralizado), Voltar sempre no mesmo
lugar, botões numa barra de ação inferior organizada, e mobile no breakpoint 760px.

## Sobre os arquivos
Os `.dc.html` são **referências de design em HTML** — protótipos, não código de
produção. Recrie no código real (`Elifoot/public/index.html`) usando as
**classes/tokens existentes** (`.cl-*`, `var(--felt)`, `var(--navy)`, etc.). Os
protótipos usam estilos inline e classes `rf-*` próprias — **traduza** pro
vocabulário real, não cole o CSS.

## Fidelidade
**Alta fidelidade.** Cores, tipografia, espaçamento e interações finais.

## Shell (idêntico às telas logadas já entregues)
- Barra de título navy: logo 18×18 + "RetroFoot98" + `_ □ ✕`.
- Nav: `Início · Sobre nós · Como jogar · Contato` + chip "100% Online" +
  `👤 lecfmpp` + **Sair**.
- Cabeçalho de etapa (46px): `‹ Voltar` esq · título uppercase centralizado ·
  pill `1/4…4/4` à direita.
- Barra de ação inferior (≥56px): primária verde à direita; secundárias esq.
- Footer padrão. Bevel 2px, cantos quadrados, grafia "Selecção/Seleccionar".

## Telas

### 1. Dinheiro (1/4)
Label amarelo "Com que moeda vai querer jogar?" + **select grande navy**
(Reais / Dólares / Euros; texto branco bold 20px, seta branca) + nota "A moeda
vale pra toda a Resenha…". CTA **✔ OK** → Jogadores.
- Substitui o dialog flutuante amarelo original; agora dentro do shell fixo.

### 2. Jogadores (2/4)
Tabela com colunas **Nome** | **Equipa** (labels amarelos uppercase). 6 linhas
`Jogador 1…6`: label à esquerda, campo de nome, coluna Equipa à direita.
**Jogador 1** = você → campo com fundo amarelo-claro (`#fff7bd`), placeholder
"LEANDRO", Equipa "(você)". Nota "Preencha o nome de cada treinador. Os vazios
ficam com a CPU." CTA **› Escolher clubes** → Escolha os clubes.

### 3. Escolha os clubes (3/4)
Cabeçalho de colunas **Jogador | País | Clube** (amarelo). Linha por jogador:
"LEANDRO _(você)_" + **select País** (Alemanha/Brasil/…) + **select Clube**
("— escolha —" / clubes do país). Selects estilo navy. Nota "Cada jogador
escolhe seu país e um clube livre."
- Ação: `🎲 Sortear` (esq); `↩ Voltar` + `✔ Começar` verde (dir) → Loading.

### 4. A iniciar o jogo (loading)
Tela sem cabeçalho de etapa nem barra de ação — só o shell + painel centrado:
faixa navy **"A iniciar o jogo…"** + barra de progresso (trilho preto com bevel
afundado, preenchimento verde, **%** mono centralizado) + nota "Montando tabelas,
elencos e calendário da temporada." Progresso anima até 100%.

## Comportamento & navegação
- Estado `view`: `moeda → jogadores → clubes → loading`. Voltar retrocede
  (1ª tela → Home). Pills de passo 1–4.
- **Começar** e **Sortear** vão pra loading; a barra incrementa até 100%
  (no protótipo, ~a cada 260ms) e então o jogo abriria.
- Selects estilizados navy (texto branco, seta custom). Campo do Jogador 1
  destacado em amarelo-claro. Chip online pisca ~1.6s.

## Responsivo (breakpoint 760px)
Desktop: janela 1100×632 centralizada no felt, escalada por JS. Abaixo de 760px:
janela largura cheia (sem scale/sombra), título sticky, nav faz wrap, chip online
some, barra de ação faz wrap. Tabela de Jogadores colapsa pra `label + campo`
(Equipa abaixo); linha de Clubes empilha País e Clube (cabeçalhos de coluna
somem). Barra de progresso ocupa a largura.

## Design tokens
`--felt #2f8f2f`, `--navy #000080`, `--chrome #c0c0c0`, `--yellow #ffff00`,
`--success #1a8f3c`, `--danger #cc0000`. Bevel 2px (claro `#fff`, escuro
`#808080`/`#707070`; inverte no `:active`); campos/trilho de progresso = bevel
afundado. Type: stacks de sistema; mono pra % e números; bold 700–800.

## Assets
`assets/logo.webp` (18×18 na barra de título). Ícones = emoji nativos. Sem SVG
próprio, exceto a setinha dos selects (data-URI simples embutida no CSS).

## Arquivos neste pacote
- `Setup do Jogo.dc.html` — as 4 telas + mobile (referência principal).
- `Home.dc.html` — referência do shell.

## Onde aplicar
`Elifoot/public/index.html`. Reimplementar com classes `.cl-*` e tokens
existentes. **Não alterar lógica de jogo/back-end** — só markup, estilos e
navegação (a barra de progresso já existe no jogo; só reestilizar).
