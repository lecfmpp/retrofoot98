# Handoff: Redesign RetroFoot98 — Conta, Modo Resenha & Novo Jogo (Desktop + Mobile)

## Visão geral
Redesign de **10 telas** do RetroFoot98, agrupadas em dois fluxos navegáveis:

**Fluxo A — Novo Jogo** (`Novo Jogo.dc.html`, 4 telas):
Escolher modo → Modo Solo → Novo jogo (nome) → Selecção de Países.

**Fluxo B — Conta & Modo Resenha** (`Conta e Resenha.dc.html`, 6 telas):
Entrar (login) → Criar conta → Modo Resenha → Abrir sala → Entrar numa Resenha → Sala (lobby).

Objetivos do redesign (valem para tudo):
1. **Header/footer fixos em todas as telas**, iguais à Home — inclusive nas
   páginas públicas (login, criar conta). Fim do **logo gigante** centralizado
   ocupando a tela; a logo aparece só 18×18 na barra de título.
2. **Botão Voltar sempre no mesmo lugar** (topo-esquerda do cabeçalho de etapa).
3. **Botões organizados numa barra de ação inferior** (primária à direita,
   secundárias à esquerda), em vez de botões soltos empilhados.
4. **Melhor uso do espaço** — telas densas (lobby) organizadas em colunas.

## Sobre os arquivos de design
Os `.dc.html` deste pacote são **referências de design feitas em HTML** —
protótipos de look & comportamento, **não** código de produção pra copiar.
A tarefa é **recriar estes designs no código real** do RetroFoot98
(`Elifoot/public/index.html`, app HTML/CSS/JS de página única) usando as
**classes e tokens já existentes** (`.cl-*`, `var(--felt)`, `var(--navy)`, etc.).
Os protótipos usam estilos inline e classes `rf-*` próprias — **traduza** pro
vocabulário real do produto, não cole o CSS do protótipo.

## Fidelidade
**Alta fidelidade (hifi).** Cores, tipografia, espaçamento e interações finais.

## Shell compartilhado (todas as 10 telas)
- **Barra de título** navy: logo 18×18 + "RetroFoot98" + botões `_ □ ✕`.
- **Barra de navegação**:
  - **Páginas públicas** (login/criar conta): `Início · Sobre nós · Como jogar ·
    Contato` à esquerda; botão **🔑 Entrar** à direita.
  - **Páginas logadas** (resto): mesmo menu + chip verde "100% Online" +
    `👤 LEANDRO TESTE` + botão **Sair**.
- **Cabeçalho de etapa** (46px, `rgba(0,0,0,.16)`): `‹ Voltar` à esquerda, título
  centralizado (uppercase, tracking 2px), à direita um pill mono quando há
  código/passo (ex.: `Código S9RJH`, `3/4`) — senão vazio.
- **Barra de ação inferior** (≥56px, `rgba(0,0,0,.16)`, borda superior clara):
  ação primária verde à direita; secundárias/hints à esquerda.
- **Corpo**: felt green full-bleed. **Footer**: `v2026.01 · © 2026 RetroFoot98`
  à esquerda; `Sobre nós · Contato · Termos · Privacidade` à direita.
- Manter **bevel 2px** (claro topo/esq, escuro base/dir; inverte no `:active`),
  cantos quadrados exceto pills e choice cards, grafia **"Selecção/Seleccionar"**.

---

## FLUXO A — Novo Jogo (`Novo Jogo.dc.html`)

### A1. Escolher modo (1/4)
Título serif "Como você quer jogar?" + 2 choice cards: 🎮 **Modo Solo**,
👥 **Modo Resenha**. Card leva ao passo seguinte. Voltar → Home.

### A2. Modo Solo (2/4)
2 choice cards: badge "NEW" **Novo jogo** (pré-selecionado) e 📁 **Continuar**
("Você tem 12 jogos salvos na nuvem"). Ambos → passo 3.

### A3. Novo jogo — nome (3/4)
Campo mono uppercase (maxlength 8, `[a-zA-Z0-9]`), label "Nome do jogo" +
contador `n/8`, nota "Só letras e números, sem espaços." CTA **✔ Começar**
(desabilitado enquanto vazio) → passo 4.

### A4. Selecção de Países (4/4)
- **Chips de resumo no topo:** `Equipas {total}`, `Equipas selec. {n}` (on),
  `Países {total}`, `Países selec. {n}` (on) + nota "Totalize pelo menos 20 equipas."
- **Duas colunas:** esquerda = lista de **Países** (bandeira + nome + contagem
  mono; hover `#eef`; selecionado navy); direita = **Competições** (2 botões
  expansíveis `🏆`/`🏅`).
- **Ação:** `▤ Todas` (esq); `✖ Cancelar` + `✔ OK` verde (dir). OK → toast
  "✓ Times sorteados!".

---

## FLUXO B — Conta & Modo Resenha (`Conta e Resenha.dc.html`)

### B1. Entrar / Login (público)
Card ~440px centrado. **Tabs segmentadas** no topo: `Já tenho conta` (ativa,
amarela) / `Criar conta nova`. Subtítulo "Entre pra acessar seus jogos salvos
na nuvem." Campos **E-mail**, **Senha** (com link `Esqueci minha senha` à direita
do label). CTA **✔ Entrar** na barra de ação → tela Modo Resenha (logado).
- Tab segmentada: caixa bevel afundada, tab ativa = fundo amarelo / texto navy;
  inativa = verde escuro / texto claro.

### B2. Criar conta (público)
Mesmo card/tabs, agora `Criar conta nova` ativa. Subtítulo "Crie sua conta pra
salvar seus jogos na nuvem e continuar em qualquer aparelho." Campos **Nome de
treinador**, **E-mail**, **Senha** + nota "Pelo menos 6 caracteres. Evite senhas
óbvias…". CTA **✔ Criar conta** → Modo Resenha.

### B3. Modo Resenha (logado)
Título serif "O que você quer fazer?" + 2 choice cards: 🏟️ **Criar nova Resenha**
("Você vira o anfitrião e convida os amigos com um código.") e 🔑 **Entrar numa
Resenha** ("Já tem o código de um amigo? Entre na Resenha dele."). Abaixo, link
amarelo "↻ Você já joga 1 Resenha — toque pra reentrar" → lobby.
- Criar nova → B4; Entrar numa → B5.

### B4. Abrir sala (logado)
Campo **Nome da sala** + nota "Cada jogador escolhe o próprio time ao entrar,
entre os clubes ainda controlados pela CPU." CTA **✔ Abrir** (desabilitado até
ter nome) → lobby. Voltar → B3.

### B5. Entrar numa Resenha (logado)
Subtítulo "Digite o código que o anfitrião te passou." Campo **Código da
Resenha** (mono uppercase, maxlength 6, letter-spacing 4px). CTA **✔ Entrar**
(habilita com ≥4 chars) → lobby. Voltar → B3.

### B6. Sala / Lobby (logado)
Cabeçalho de etapa: `‹ Sair da sala` · "SALA · TESTE" · pill `Código S9RJH`.
**Duas colunas** (rolam internamente):
- **Esquerda (flex 1.4):**
  - Painel **Convidar treinadores** — grid 2 col: 🟢 WhatsApp (prefixo `+55` +
    campo "DDD + número" + Enviar) e ✉ e-mail (campo + Enviar); abaixo
    "Link da sala: retrofoot98.com.br/?sala=S9RJH".
  - Painel **🔍 Convidar quem já tem conta** — campo de busca "Buscar por nome
    ou e-mail (mín. 3 letras)".
  - **Participantes (1)** — linha: bolinha verde + "LEANDRO TESTE _(anfitrião)_"
    + "Confirmado" + select "Escolher time…".
- **Direita (flex 1):**
  - Painel **Partida** — botão largo "🎲 Sortear times"; "Velocidade do jogo" com
    toggles `1x 1.5x 2x 3x 5x` (selecionado = navy/branco).
  - Painel **💬 Chat da sala** — área vazia "Nenhuma mensagem ainda. Diga oi! 👋"
    + campo "Escreva uma mensagem…" + Enviar.
- **Ação:** hint "Mínimo de 2 treinadores pra começar." (esq); `✖ Sair` +
  `✔ Começar` (verde, desabilitado com <2 jogadores) (dir).

---

## Comportamento & navegação
- Estado `view` controla a tela; `Voltar` retrocede (na 1ª tela de cada fluxo,
  volta à Home). Shell alterna público/logado conforme a view.
- Campos com validação: nome do jogo (`[a-zA-Z0-9]`, ≤8), nome da sala
  (não-vazio), código da Resenha (alfanumérico, ≤6, habilita CTA com ≥4).
- Toggle de velocidade: seleção única, estado visual navy.
- Toast (Países/Novo Jogo): navy, bevel, fade-up ~1.6s.
- Chip online: bolinha verde piscando (~1.6s). Transições sutis só em hover.

## Responsivo (breakpoint único: 760px)
Desktop: "janela" 1100×632 centralizada no felt, escalada por JS
(`transform: scale`) pra caber na viewport.
Abaixo de 760px:
- Janela vira **largura cheia** (sem scale/sombra/moldura); página rola.
- Barra de título sticky; nav faz wrap; chip "100% Online" some.
- Choice cards, colunas de Países e colunas do lobby **empilham**; grid de
  convites vira 1 coluna.
- Barra de ação faz wrap.
> No codebase real, seguir o padrão mobile já existente (janela full-width,
> botões em coluna, ação primária acessível no rodapé).

## Design tokens
- `--felt #2f8f2f`, `--navy #000080`, `--chrome #c0c0c0`, `--yellow #ffff00`,
  `--success #1a8f3c` (OK/online), `--danger #cc0000` (cancelar/sair).
- Bevel 2px (claro `#fff`, escuro `#808080`/`#707070`; inverte no `:active`);
  campos = bevel afundado.
- Radius só em pills (12px / 999px) e choice cards (12px); resto quadrado.
- Tipografia: stacks de sistema (Tahoma/Segoe UI; Georgia itálico decorativo;
  mono pra números/códigos). Bold (700–800) carrega a hierarquia.

## Assets
- `assets/logo.webp` (500×500 transparente; usada 18×18 na barra de título).
- Ícones = **emoji nativos** (sistema oficial do DS). Não criar SVG/icon font.

## Arquivos neste pacote
- `Novo Jogo.dc.html` — Fluxo A (4 telas + mobile).
- `Conta e Resenha.dc.html` — Fluxo B (6 telas + mobile).
- `Home.dc.html` — referência do shell (header/nav/footer).

## Onde aplicar
`Elifoot/public/index.html` — app de produção. Reimplementar estes fluxos com as
classes `.cl-*` e tokens existentes. **Não alterar lógica de jogo/back-end** —
apenas markup, estilos e navegação destas telas.
