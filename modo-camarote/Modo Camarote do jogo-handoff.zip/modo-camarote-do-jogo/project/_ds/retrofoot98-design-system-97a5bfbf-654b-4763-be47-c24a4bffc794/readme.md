# RetroFoot98 — Design System

RetroFoot98 is a browser-based football **management** game (in the lineage of Elifoot 98 / classic Championship Manager), played in Brazilian Portuguese, solo vs. the machine or online with friends ("Modo Resenha"). The player is the manager: pick the tactic, negotiate players, run the club's finances, and fight through Série A–D and cups (Libertadores, Sul-Americana, Copa do Brasil).

Its visual identity is a deliberate **retro Windows 98 desktop** aesthetic — chamfered 3D-bevel windows, a navy title bar, chrome-gray "chrome" buttons that physically depress. It is a **real product in production**, not a mockup. This design system **extracts and systematizes the look and voice the game already has** — it does not recolor or re-typographize from scratch.

The whole app ships today as a single vanilla HTML/CSS/JS page (no component framework). All values here were lifted directly from that production CSS.

## Sources

- **Codebase (read-only, mounted):** `Elifoot/` — the production app. Ground truth CSS + copy lives in `Elifoot/public/index.html` (~6000 lines, single-file app). `Elifoot/public/index_v1_old.html` is a superseded version.
- **Brief:** `Elifoot/design-system-brief.md` — colors, type, components extracted from prod CSS by the team.
- **Assets:** `Elifoot/Imagens/`, `Elifoot/public/img/` (logo + feature badges), `Elifoot/trofeus/` (competition trophies).
- **Uploaded:** `uploads/retrofoot98-no-bg.webp` (the logo, 500×500, transparent).
- **Reports:** `Elifoot/relatorios/` — simulation-engine PDF + a "later mechanics" ideas markdown (game logic, not design).

---

## CONTENT FUNDAMENTALS — how RetroFoot98 writes

The voice is a **Brazilian football fan explaining the screen to a friend** — never a product manual, never corporate.

- **Language:** Brazilian Portuguese (PT-BR). Second person, informal — the game addresses the player as **"você"**.
- **Tone:** direct, no fluff. Short sentences. **Imperative** when instructing ("Escolha a tática no menu Seleccionar primeiro.", "Toque primeiro num titular (T) pra substituir."); **factual** when reporting status ("Jogo gravado na nuvem.", "Times sorteados!", "Login feito!").
- **Real Brazilian futebolês:** uses supporter/commentator vocabulary where it fits — *"arrematado no leilão"*, *"sorteio dos jogos da taça"*, *"à espera dos treinadores"*, *"Chamar pra Resenha"* — not literal translations of English game terms.
- **Punctuation with personality:** ellipses (…) for loading/in-progress states ("Conectando…", "Carregando jogo…", "Abrindo WhatsApp…", "À espera do anfitrião…"); moderate exclamation for good confirmations ("Conta criada!", "Pronto! À espera dos outros treinadores."). No emoji-in-every-sentence gamified-app energy.
- **Numbers can be spelled out for warmth.** The original writes money in words in prose contexts — e.g. *"Dinheiro em caixa: 1 milhão e 250 mil reais"* — while tabular/field values stay in mono digits (`R$ 1.250.000`). Prose = words; columns = mono numerals.
- **Menu convention:** items that open a dialog end in `…` ("Classificação…", "Renovar contrato…", "Calendário…"); a bare label performs an action. Keyboard accelerator letters may sit right-aligned in the dropdown.
- **Emoji as functional glyphs, sparingly:** ⚠ before warnings, ✓/✔ before confirmations, 🔨 for an auction result, ⏩ for "skip". They punctuate a message; they don't decorate every line.

### The intentional spelling quirk — DO NOT "correct"
The game uses **European-Portuguese spelling on specific football terms** as an homage to the original Elifoot: **"Selecção", "Seleccionar", "Selecciona"** (with **cç**), instead of PT-BR "Seleção/Selecionar". This is part of the identity. Keep the **cç** spelling on those specific terms even though the rest of the copy is standard PT-BR. (You'll also see "guardadas", "equipa", "à espera", "a ligar à sala" — same flavor, keep them.)

### Never
Corporate, motivational, or product-jargon voice ("desbloqueie", "otimize sua experiência", "maximize seu potencial"). If a line sounds like a productivity app, it's wrong for this brand.

**Real examples (verbatim from production):**
- Loading: `Conectando...` · `Entrando...` · `Carregando jogo…` · `Enviando convite por e-mail…`
- Success: `Conta criada!` · `Times sorteados!` · `Jogo gravado na nuvem.` · `✓ Contrato renovado com sucesso.` · `Opções guardadas.`
- Instruction: `Escolha a tática no menu Seleccionar primeiro.` · `Selecciona um jogador na lista primeiro.`
- Warning: `⚠ Caixa insuficiente para renovar este contrato.` · `Máximo de 3 substituições.`
- Waiting: `À espera dos treinadores 2/4` · `À espera do anfitrião…`

---

## VISUAL FOUNDATIONS

### The signature: the 3D bevel
The chamfered 1998 bevel is **the** differentiator. Every clickable / windowed element uses a **2px** border with light on top+left and dark on bottom+right:

```css
/* "para fora" — button at rest, raised panel */
border: 2px solid; border-color: var(--bevL) var(--bevD2) var(--bevD2) var(--bevL);
/* "pressionado" — :active, sunken panel (inverts) */
border-color: var(--bevD2) var(--bevL) var(--bevL) var(--bevD2);
/* "campo" — inputs (sunken, softer, using --bevD/--bevL) */
border-color: var(--bevD) var(--bevL) var(--bevL) var(--bevD);
```
**Never** replace this with soft `box-shadow`, glassmorphism, or flat design — that destroys the product. Tokens: `--bevel-out`, `--bevel-in`, `--bevel-field`.

### Corners
**Square by default.** `border-radius` appears in only **two deliberate places**: small badges/pills (`--radius-pill` 12px, plus `--radius-tag` 3px / `--radius-chip` 99px for micro-tags/status chips) and the modern **choice cards** (Solo vs Resenha, `--radius-pill` 12px). Everything else is square.

### Color
Fixed, limited palette — **do not introduce a parallel "more modern" palette.**
- **Grass green** `--felt #2f8f2f` — the default full-screen background of nearly every screen (like table felt / the pitch).
- **Navy** `--navy #000080` — title bars, dialog frames, selected rows, highlighted text.
- **Chrome gray** `--chrome #c0c0c0` — buttons and neutral panels.
- **Yellow** `--yellow #ffff00` — labels, titles, active links, focus (`--yellowlite #ffff66`).
- **Functional colors already exist and must be reused, not redefined:** green = success/OK, red = cancel/error, gold = secondary qualification zone (Sul-Americana). See `tokens/colors.css`.
- **Window bodies vary by context:** green (`--body-green`, main actions), pastel yellow (`--body-yellow #ffffcc`, draws/auctions), chrome (`--body-gray`, options/forms).

### Type
System stacks only (see Typography). **Bold is the primary emphasis tool** — there isn't much size variation, so 700–800 weight carries hierarchy. Serif (Georgia, italic/bold) is decorative: manager name, hero titles, penalty-modal result. Mono for anything numeric (scores, money, room code, clock) — right-aligned, tabular.

### Spacing & density
**Density is acceptable and expected** — this audience wants tables, stats, money on screen. Do **not** simplify screens by cutting data to "let them breathe". Adjust hierarchy and spacing, not content. Padding is tight and functional (dialog body `18px 20px`, buttons `8px 14px`).

### Backgrounds
No imagery, gradients, textures, or patterns as backgrounds — just **flat felt green** full-bleed, with floating windows centered on top. The only gradients are functional: the chrome top-bar (`#d8d8d8→#c0c0c0`), the morale bar (`--moral-grad`), and the live-match clock (conic-gradient countdown).

### Animation
Minimal and purposeful. `transition: width .18s` on progress bars; `transition: background .15s` on choice-card hover; a `steps()` pulse on the urgent "waiting for managers" bar; a pulse on penalty suspense dots. **No decorative loops, no bounce, no easing flourishes.** Movement communicates state, nothing else.

### Hover / press states
- **Hover:** rows/list items go to a light tint (`#e8e8e8`, `#eef`, `#ddd`) or navy-selected (`#000080` bg, white text). Choice cards raise translucency and turn the border yellow.
- **Press:** buttons **invert the bevel** (`--bevel-out` → `--bevel-in`) — a physical "push in". They do **not** change color on press. This is the correct press feedback everywhere.
- **Disabled:** text goes gray `#808080`, icon opacity `.4`. Cursor default.

### Borders, shadows, elevation
Bevel is the elevation system. Real `box-shadow` is reserved for **floating windows** (`--shadow-dlg`, `--shadow-main`) and **badges** (`--shadow-badge`) — never on buttons or fields. Tables have **no grid lines** — rows separate by alternating fill or a club-color side stripe; classification zones get a 4px colored left bar + a text badge.

### Layout rules
Root is always centered (`flex; align-items:center; justify-content:center`) on full-screen felt. **One breakpoint: 760px.** Below it: windows go full-width (no centering), button groups stack to a column, tables shrink font/columns, and the primary action (e.g. "Jogar") becomes `position:fixed` at the footer so it's always reachable. No formal grid system — flexbox per component. Keep this mobile pattern; don't reinvent it.

### Transparency / blur
Used only in the "modern" touches: choice cards and the country-screen option toggles use `rgba(255,255,255,.1)` translucent fills over the felt. No backdrop-blur anywhere. Everything else is opaque.

---

## ICONOGRAPHY

- **Native emoji ARE the icon system** — this is intentional (light, universal, matches the casual/retro tone). No custom icon set, no icon font, no SVG icon library. Common glyphs in production: ⚽ 👥 💬 🔴 🟢 ✔ ✖ 💰 📤 🔄 📅 ⏳ 🔨 ⚠ ✓ ↩ ⏩. Buttons stack the emoji (20px) above the label by default.
- **Custom art is reserved for exactly three things**, all real illustrated/pixel-art assets (never emoji, never hand-drawn SVG):
  1. **Logo** — `assets/logo.webp` (500×500, transparent): pixel-art shield/crest, football on top, black center band reading "RETROFOOT98" (RETRO+FOOT white, "98" gold), green-striped field, white star at base. Also used at 18×18 in the top bar and as favicon/app icon.
  2. **Feature badges** — `assets/badge-clubes.webp`, `assets/badge-liga.webp`, `assets/badge-chat.webp`: same crest style, one themed icon each, shown ~96px on the landing screen.
  3. **Competition trophies** — `assets/trofeu-*.webp|jpg`: Série A/B/C/D, Copa do Brasil, Libertadores, Sul-Americana. Shown 30px in the dialog badge/seal, larger on competition screens.
- **Do not** draw new icons as SVG or invent a custom set. If a new glyph is needed, use an emoji consistent with the set above.

See the "Brand" cards in the Design System tab for the real logo, badges, and trophies.

---

## Reference validation
The current documented system and its recreations were cross-checked against **screenshots of the original Elifoot 98** (the reference the product is modeled on), in `screenshots/`. Confirmed against the original: felt-green full-screen desk; navy title bar; the roster grouped by position (G/D/M/A) with a *Forma* + value column; the right match panel with **five** tabs (Jogo / Jogador / Finanças / Selecção / **Adversário**); club-color **team stripes** everywhere a team is named; the **yellow morale bar** on chrome; the division-grouped **live match** board with attendance figures (gold mono, left of each row) and a conic countdown clock; the bevelled **fieldset** legend boxes (Historial, Árbitro). These informed `TeamStripe` and `Fieldset`. Note: the original groups roster positions with whitespace + a hairline rather than header bars — our recreation's header bars are a mild, intentional legibility improvement.

## Intentional additions
None invented beyond the source. All components below map to real production classes (`.cl-*`). The React components are cosmetic recreations of those classes exposed as a reusable API.

---

## Index / manifest

**Root**
- `styles.css` — entry point (@import list only).
- `tokens/` — `colors.css`, `typography.css`, `spacing.css` (CSS custom properties).
- `assets/` — logo, feature badges, competition trophies.
- `SKILL.md` — Agent-Skills-compatible wrapper.

**Foundations** (Design System tab → Colors / Type / Spacing / Brand): specimen cards under `guidelines/`.

**Components** (`components/`, group "Components"): see each dir's card + `.prompt.md`.
- `window/` — `Window`, `WindowBadge`, `Fieldset` (dialog frame, title bar, context bodies, floating trophy seal, bevelled legend box)
- `buttons/` — `Button` (all variants: ok/cancel/big/wide/sm/mini/online), `TabButton`
- `forms/` — `Input`, `Select`, `MoneyField`, `Radio`, `SpinField`
- `data/` — `Badge`, `StatBar` (incl. morale gradient), `ZoneTag`, `ChoiceCard`, `TeamStripe` (club-color stripe w/ auto-contrast)
- `feedback/` — `Toast`

**UI kits** (`ui_kits/`): full-screen recreations.
- `game/` — landing (Acerca), mode choice, the logged-in hub (roster + match panel), a live match, an auction modal, classification table.

---

## Evolution proposals
None included. Everything here is **the documented current system**. If a visual evolution is ever proposed, it will be clearly separated and labeled "proposta de evolução" — never mixed into the documented system without notice.
