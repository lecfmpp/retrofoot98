/* @ds-bundle: {"format":4,"namespace":"RetroFoot98DesignSystem_97a5bf","components":[{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"TabButton","sourcePath":"components/buttons/TabButton.jsx"},{"name":"Badge","sourcePath":"components/data/Badge.jsx"},{"name":"ChoiceCard","sourcePath":"components/data/ChoiceCard.jsx"},{"name":"StatBar","sourcePath":"components/data/StatBar.jsx"},{"name":"TeamStripe","sourcePath":"components/data/TeamStripe.jsx"},{"name":"ZoneTag","sourcePath":"components/data/ZoneTag.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"MoneyField","sourcePath":"components/forms/MoneyField.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"SpinField","sourcePath":"components/forms/SpinField.jsx"},{"name":"Fieldset","sourcePath":"components/window/Fieldset.jsx"},{"name":"Window","sourcePath":"components/window/Window.jsx"},{"name":"WindowBadge","sourcePath":"components/window/WindowBadge.jsx"}],"sourceHashes":{"components/buttons/Button.jsx":"5ae47e3f00f9","components/buttons/TabButton.jsx":"3a06d1a4f35e","components/data/Badge.jsx":"861154b64d4a","components/data/ChoiceCard.jsx":"660b32190866","components/data/StatBar.jsx":"d0db6dd04005","components/data/TeamStripe.jsx":"1c03f4d7dac1","components/data/ZoneTag.jsx":"341fe34ff903","components/feedback/Toast.jsx":"9e6c14142eb6","components/forms/Input.jsx":"80621d9c3122","components/forms/MoneyField.jsx":"8a3b30b50224","components/forms/Radio.jsx":"987eacc699c0","components/forms/Select.jsx":"69a95524422d","components/forms/SpinField.jsx":"0a102a15f2b5","components/window/Fieldset.jsx":"cfc6d20a61c9","components/window/Window.jsx":"99f0c1860f0c","components/window/WindowBadge.jsx":"2f78e5398460","ui_kits/game/hub.jsx":"9934177fa08a","ui_kits/game/overlays.jsx":"f6b0d7e9f5ed","ui_kits/game/screens.jsx":"d434ce5f248e"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.RetroFoot98DesignSystem_97a5bf = window.RetroFoot98DesignSystem_97a5bf || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — the Win98 chrome button. Bevel "out" at rest, inverts to "in" on press.
 * Icon (emoji) stacks above the label by default; `inline` puts it beside.
 */
function Button({
  children,
  icon,
  variant = "default",
  // default | ok | cancel | online
  size = "md",
  // sm | md | big | wide
  inline = false,
  disabled = false,
  onClick,
  style = {},
  ...rest
}) {
  const [pressed, setPressed] = React.useState(false);
  const sizes = {
    sm: {
      padding: "5px 9px",
      minWidth: 42,
      minHeight: 28,
      fontSize: 11,
      ic: 13,
      gap: 2
    },
    md: {
      padding: "8px 14px",
      minWidth: 70,
      minHeight: 46,
      fontSize: 13,
      ic: 20,
      gap: 3
    },
    big: {
      padding: "14px 18px",
      minWidth: 90,
      minHeight: 56,
      fontSize: 13,
      ic: 26,
      gap: 3
    },
    wide: {
      padding: "18px 34px",
      minWidth: 90,
      minHeight: 56,
      fontSize: 15,
      ic: 20,
      gap: 3,
      weight: 700
    }
  };
  const s = sizes[size] || sizes.md;
  const online = variant === "online";
  const bg = online ? "var(--success)" : "var(--chrome)";
  const fg = online ? "#fff" : disabled ? "var(--bevD)" : "#000";
  const borderColor = online ? "var(--success-lite) var(--success-deep) var(--success-deep) var(--success-lite)" : pressed && !disabled ? "var(--bevel-in)" : "var(--bevel-out)";
  const icColor = variant === "ok" ? "var(--success-alt)" : variant === "cancel" ? "var(--danger)" : "inherit";
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseDown: () => setPressed(true),
    onMouseUp: () => setPressed(false),
    onMouseLeave: () => setPressed(false),
    style: {
      fontFamily: "var(--sans)",
      fontSize: s.fontSize,
      fontWeight: online ? 800 : s.weight || 400,
      background: bg,
      color: fg,
      border: "2px solid",
      borderColor,
      borderRadius: 0,
      padding: s.padding,
      minWidth: s.minWidth,
      minHeight: s.minHeight,
      cursor: disabled ? "default" : "pointer",
      display: "inline-flex",
      flexDirection: inline ? "row" : "column",
      alignItems: "center",
      justifyContent: "center",
      gap: inline ? 8 : s.gap,
      boxSizing: "border-box",
      textAlign: "center",
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: inline ? s.fontSize + 4 : s.ic,
      lineHeight: 1,
      color: icColor,
      opacity: disabled ? 0.4 : 1
    }
  }, icon), children && /*#__PURE__*/React.createElement("span", null, children));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/TabButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TabButton — the dark match-panel tab. Active: near-black fill, yellow 2px underline,
 * white bold text. Inactive: light gray text, no fill.
 */
function TabButton({
  children,
  active = false,
  onClick,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    style: {
      padding: "3px 12px",
      fontSize: 14,
      cursor: "pointer",
      color: active ? "#fff" : "#ccc",
      fontWeight: active ? 700 : 400,
      border: "1px solid",
      borderColor: active ? "#888 #888 #000 #888" : "transparent",
      background: active ? "#111" : "transparent",
      borderBottom: active ? "2px solid var(--yellow)" : "1px solid transparent",
      userSelect: "none",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { TabButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/TabButton.jsx", error: String((e && e.message) || e) }); }

// components/data/Badge.jsx
try { (() => {
/**
 * Badge — small status pills used across the game. Presets map to real classes:
 * online (green "100% Online" chip), zone-lib, zone-sul, status ok/off/out,
 * win-open/win-closed, generic bevel pill.
 */
function Badge({
  preset = "bevel",
  children,
  style = {}
}) {
  const presets = {
    online: {
      background: "var(--success)",
      color: "#fff",
      border: "1px solid var(--success-deep)",
      borderRadius: 99,
      fontWeight: 800,
      fontSize: 13,
      padding: "4px 12px",
      letterSpacing: ".3px"
    },
    "zone-lib": {
      background: "var(--zone-lib-bg)",
      color: "var(--zone-lib-fg)",
      borderRadius: 3,
      fontWeight: 800,
      fontSize: 10,
      padding: "2px 5px"
    },
    "zone-sul": {
      background: "var(--zone-sul-bg)",
      color: "var(--zone-sul-fg)",
      borderRadius: 3,
      fontWeight: 800,
      fontSize: 10,
      padding: "2px 5px"
    },
    ok: {
      background: "var(--success-alt)",
      color: "#fff",
      borderRadius: 3,
      fontWeight: 700,
      fontSize: 11,
      padding: "3px 8px"
    },
    off: {
      background: "var(--gray-999)",
      color: "#fff",
      borderRadius: 3,
      fontWeight: 700,
      fontSize: 11,
      padding: "3px 8px"
    },
    out: {
      background: "#b03030",
      color: "#fff",
      borderRadius: 3,
      fontWeight: 700,
      fontSize: 11,
      padding: "3px 8px"
    },
    "win-open": {
      background: "#1a6b1a",
      color: "#fff",
      borderRadius: 3,
      fontWeight: 800,
      fontSize: 10,
      padding: "2px 6px"
    },
    "win-closed": {
      background: "var(--gray-888)",
      color: "#fff",
      borderRadius: 3,
      fontWeight: 800,
      fontSize: 10,
      padding: "2px 6px"
    },
    start: {
      background: "var(--yellow)",
      color: "#000",
      borderRadius: 3,
      fontWeight: 900,
      fontSize: 9,
      padding: "1px 5px",
      textTransform: "uppercase"
    },
    bevel: {
      background: "#fff",
      color: "#111",
      border: "2px solid",
      borderColor: "var(--bevel-out)",
      borderRadius: 12,
      fontWeight: 800,
      fontSize: 13,
      padding: "5px 12px"
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      whiteSpace: "nowrap",
      ...presets[preset],
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data/ChoiceCard.jsx
try { (() => {
/**
 * ChoiceCard — the "modern" decision card (Solo vs Resenha). Translucent white fill,
 * 12px radius, border goes yellow on hover. The one place the vintage meets modern UI.
 */
function ChoiceCard({
  icon,
  title,
  desc,
  onClick,
  style = {}
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: 260,
      background: hover ? "rgba(255,255,255,.22)" : "rgba(255,255,255,.1)",
      border: "2px solid",
      borderColor: hover ? "var(--yellow)" : "rgba(255,255,255,.35)",
      borderRadius: 12,
      padding: "22px 18px",
      textAlign: "center",
      cursor: "pointer",
      transition: "background .15s",
      boxSizing: "border-box",
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 40,
      marginBottom: 10
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--yellow)",
      fontWeight: 800,
      fontSize: 18,
      marginBottom: 8
    }
  }, title), desc && /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--ontext-lite)",
      fontSize: 13,
      lineHeight: 1.4
    }
  }, desc));
}
Object.assign(__ds_scope, { ChoiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ChoiceCard.jsx", error: String((e && e.message) || e) }); }

// components/data/StatBar.jsx
try { (() => {
/**
 * StatBar — the bevelled progress bar. Default: yellow fill on chrome track.
 * `morale` renders the fixed red→green gradient with the empty portion masked
 * by a chrome overlay, so the filled tip always shows the right morale color.
 */
function StatBar({
  value = 0,
  morale = false,
  large = false,
  style = {}
}) {
  const v = Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 22,
      border: "2px solid",
      borderColor: "var(--bevel-field)",
      marginTop: 6,
      maxWidth: large ? "100%" : 360,
      position: "relative",
      overflow: "hidden",
      background: morale ? "var(--moral-grad)" : "var(--chrome)",
      ...style
    }
  }, morale ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 0,
      right: 0,
      height: "100%",
      background: "var(--chrome)",
      width: `calc(100% - ${v}%)`
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      background: "var(--yellow)",
      width: `${v}%`
    }
  }));
}
Object.assign(__ds_scope, { StatBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatBar.jsx", error: String((e && e.message) || e) }); }

// components/data/TeamStripe.jsx
try { (() => {
/**
 * TeamStripe — a club-colored name stripe (the production `clubStripe()`): primary
 * color as background, secondary as text, with automatic contrast so the name is
 * always legible. Used in live-match rows, auctions, lineups, lobby team pickers.
 */
function TeamStripe({
  primary = "#000080",
  secondary,
  children,
  size = "md",
  style = {}
}) {
  // relative luminance → pick a legible text color if secondary is missing/low-contrast
  const lum = hex => {
    const h = hex.replace("#", "");
    const n = h.length === 3 ? h.split("").map(c => c + c).join("") : h;
    const r = parseInt(n.slice(0, 2), 16),
      g = parseInt(n.slice(2, 4), 16),
      b = parseInt(n.slice(4, 6), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  };
  const bgLum = lum(primary);
  let fg = secondary;
  if (!fg) fg = bgLum > 0.6 ? "#000" : "#fff";else {
    // if declared secondary doesn't contrast with primary, fall back to black/white
    if (Math.abs(lum(fg) - bgLum) < 0.32) fg = bgLum > 0.6 ? "#000" : "#fff";
  }
  const sizes = {
    sm: {
      padding: "3px 8px",
      fontSize: 13
    },
    md: {
      padding: "5px 10px",
      fontSize: 15
    },
    lg: {
      padding: "6px 12px",
      fontSize: 16
    }
  }[size];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      background: primary,
      color: fg,
      fontWeight: 700,
      border: "1px solid rgba(255,255,255,.25)",
      textShadow: "0 1px 1px rgba(0,0,0,.4)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis",
      ...sizes,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { TeamStripe });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/TeamStripe.jsx", error: String((e && e.message) || e) }); }

// components/data/ZoneTag.jsx
try { (() => {
/**
 * ZoneTag — a classification-zone marker: colored text badge, optionally wrapped
 * so the parent row can also carry the 4px colored left bar. Matches .cl-cls-zone.
 */
function ZoneTag({
  zone = "lib",
  children,
  style = {}
}) {
  const map = {
    lib: {
      background: "var(--zone-lib-bg)",
      color: "var(--zone-lib-fg)"
    },
    sul: {
      background: "var(--zone-sul-bg)",
      color: "var(--zone-sul-fg)"
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 3,
      fontSize: 10,
      fontWeight: 800,
      padding: "2px 5px",
      borderRadius: 3,
      whiteSpace: "nowrap",
      ...map[zone],
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { ZoneTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ZoneTag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
/**
 * Toast — the navy bevelled status message that appears bottom-center.
 * Content is written in the brand voice (see readme CONTENT FUNDAMENTALS).
 */
function Toast({
  children,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#000080",
      color: "#fff",
      padding: "9px 16px",
      fontSize: 13,
      fontWeight: 600,
      border: "2px solid",
      borderColor: "var(--bevel-out)",
      display: "inline-block",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — sunken white field with the "campo" bevel (bevD/bevL). No focus glow;
 * focus is signalled by the bevel + optional yellow-lite fill.
 */
function Input({
  focusHighlight = false,
  style = {},
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("input", _extends({
    onFocus: e => {
      setFocused(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocused(false);
      rest.onBlur && rest.onBlur(e);
    },
    style: {
      fontFamily: "var(--sans)",
      fontSize: 15,
      padding: "5px 8px",
      border: "2px solid",
      borderColor: "var(--bevel-field)",
      background: focusHighlight && focused ? "var(--yellowlite)" : "#fff",
      color: "#000",
      outline: "none",
      borderRadius: 0,
      boxSizing: "border-box",
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/MoneyField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * MoneyField — sunken white field, dark-green "R$" prefix, right-aligned mono value.
 * Matches .cl-money-field.
 */
function MoneyField({
  value,
  currency = "R$",
  onChange,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      background: "#fff",
      border: "2px solid",
      borderColor: "var(--bevel-field)",
      padding: "0 10px",
      width: 220,
      maxWidth: "100%",
      boxSizing: "border-box",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 800,
      color: "var(--success)",
      fontSize: 15,
      flex: "0 0 auto"
    }
  }, currency), /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    onChange: onChange,
    style: {
      border: "none",
      outline: "none",
      background: "transparent",
      flex: 1,
      minWidth: 0,
      fontFamily: "var(--mono)",
      fontSize: 16,
      fontWeight: 700,
      color: "#000",
      textAlign: "right",
      padding: "7px 0",
      fontVariantNumeric: "tabular-nums"
    }
  }, rest)));
}
Object.assign(__ds_scope, { MoneyField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/MoneyField.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Radio — the navy custom radio (.cl-radio). `light` variant for dark backgrounds.
 */
function Radio({
  checked = false,
  label,
  onChange,
  light = false,
  style = {},
  ...rest
}) {
  const accent = light ? "#fff" : "var(--navy)";
  return /*#__PURE__*/React.createElement("label", _extends({
    onClick: onChange,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      color: light ? "#fff" : "var(--navy)",
      fontWeight: 700,
      fontSize: light ? 15 : 18,
      cursor: "pointer",
      margin: "4px 0",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14,
      height: 14,
      borderRadius: "50%",
      border: `2px solid ${accent}`,
      background: "#fff",
      display: "inline-block",
      position: "relative",
      flex: "0 0 auto"
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      content: "''",
      position: "absolute",
      inset: 3,
      borderRadius: "50%",
      background: light ? "#000" : "var(--navy)"
    }
  })), label);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Select — navy dropdown, bold white text, sunken bevel. Matches .cl-select.
 */
function Select({
  children,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("select", _extends({
    style: {
      fontFamily: "var(--sans)",
      fontSize: 22,
      fontWeight: 700,
      color: "#fff",
      background: "var(--navy)",
      border: "2px solid",
      borderColor: "var(--bevel-field)",
      padding: "6px 8px",
      outline: "none",
      borderRadius: 0,
      boxSizing: "border-box",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/SpinField.jsx
try { (() => {
/**
 * SpinField — mono value + stacked ▲/▼ chrome nudge buttons, sunken bevel frame.
 * Matches .cl-spin (used in "renovar contrato").
 */
function SpinField({
  value,
  onUp,
  onDown,
  style = {}
}) {
  const nudge = {
    border: "1px solid",
    borderColor: "var(--bevel-out)",
    background: "var(--chrome)",
    fontSize: 9,
    lineHeight: 1,
    cursor: "pointer",
    flex: 1,
    padding: "0 6px"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      alignItems: "stretch",
      border: "2px solid",
      borderColor: "var(--bevel-field)",
      background: "#fff",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      minWidth: 110,
      padding: "6px 10px",
      fontFamily: "var(--mono)",
      fontSize: 22,
      fontWeight: 800,
      color: "#000"
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      borderLeft: "1px solid var(--bevD)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: nudge,
    onClick: onUp
  }, "\u25B2"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: nudge,
    onClick: onDown
  }, "\u25BC")));
}
Object.assign(__ds_scope, { SpinField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SpinField.jsx", error: String((e && e.message) || e) }); }

// components/window/Fieldset.jsx
try { (() => {
/**
 * Fieldset — the bevelled legend box used for grouped read-outs (player Historial,
 * Árbitro, substitution columns, options groups). On dark panels the legend is
 * yellow and the border a hairline; on light bodies it uses the sunken field bevel.
 */
function Fieldset({
  legend,
  tone = "dark",
  children,
  style = {}
}) {
  const dark = tone === "dark";
  return /*#__PURE__*/React.createElement("fieldset", {
    style: {
      border: dark ? "1px solid var(--bevD)" : "2px solid",
      borderColor: dark ? "var(--bevD)" : "var(--bevel-field)",
      margin: 0,
      padding: "8px 12px 12px",
      background: dark ? "transparent" : "#fff",
      ...style
    }
  }, legend != null && /*#__PURE__*/React.createElement("legend", {
    style: {
      padding: "0 6px",
      color: dark ? "var(--yellow)" : "#000",
      fontWeight: 800,
      fontSize: 14
    }
  }, legend), children);
}
Object.assign(__ds_scope, { Fieldset });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/window/Fieldset.jsx", error: String((e && e.message) || e) }); }

// components/window/Window.jsx
try { (() => {
/**
 * Window — the RetroFoot98 floating dialog. Navy 3px frame, optional title bar
 * with a Win98 minimize box, and a body whose fill switches by context.
 * A WindowBadge (trophy/logo seal) can float over the top-left corner via `badge`.
 */
function Window({
  title,
  body = "green",
  // green | yellow | gray | estadio
  minimizable = false,
  badge = null,
  children,
  style = {},
  bodyStyle = {},
  width
}) {
  const bodyBg = {
    green: "var(--body-green)",
    yellow: "var(--body-yellow)",
    gray: "var(--body-gray)",
    estadio: "var(--body-estadio)"
  }[body] || "var(--body-green)";
  const grayBevel = body === "gray";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      padding: 3,
      boxShadow: "var(--shadow-dlg)",
      maxWidth: "calc(100vw - 24px)",
      position: "relative",
      width,
      boxSizing: "border-box",
      ...style
    }
  }, badge, title != null && /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      color: "#fff",
      fontWeight: 700,
      fontSize: 14,
      padding: "5px 8px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      position: "relative"
    }
  }, minimizable && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 6,
      top: 4,
      width: 16,
      height: 14,
      background: "var(--chrome)",
      border: "1px solid #000",
      fontSize: 10,
      lineHeight: "8px",
      textAlign: "center",
      color: "#000"
    }
  }, "_"), title), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 20px",
      position: "relative",
      background: bodyBg,
      border: grayBevel ? "2px solid" : undefined,
      borderColor: grayBevel ? "var(--bevel-out)" : undefined,
      color: body === "green" || body === "estadio" ? "#fff" : "#000",
      ...bodyStyle
    }
  }, children));
}
Object.assign(__ds_scope, { Window });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/window/Window.jsx", error: String((e && e.message) || e) }); }

// components/window/WindowBadge.jsx
try { (() => {
/**
 * WindowBadge — the rounded white seal that floats over a Window's top-left corner
 * (the ONLY place large border-radius is allowed besides choice cards). Holds a
 * 30px trophy/logo image + short bold label. Matches .cl-dlg-badge.
 */
function WindowBadge({
  img,
  imgAlt = "",
  children,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: -16,
      left: 14,
      zIndex: 3,
      display: "flex",
      alignItems: "center",
      gap: 7,
      background: "#fff",
      border: "2px solid",
      borderColor: "var(--bevel-out)",
      borderRadius: 12,
      padding: "5px 12px 5px 5px",
      boxShadow: "var(--shadow-badge)",
      ...style
    }
  }, img && /*#__PURE__*/React.createElement("img", {
    src: img,
    alt: imgAlt,
    style: {
      width: 30,
      height: 30,
      display: "block",
      objectFit: "contain"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 800,
      fontSize: 13,
      color: "#111",
      whiteSpace: "nowrap",
      letterSpacing: ".2px"
    }
  }, children));
}
Object.assign(__ds_scope, { WindowBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/window/WindowBadge.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game/hub.jsx
try { (() => {
/* Hub — the logged-in main screen. Left: roster grouped by position.
   Right: match panel with tabs (Jogo / Jogador / Finanças / Selecção). */
const {
  Btn
} = window.RF;
const ROSTER = {
  "Goleiros": [["G", "Taffarel", 88, "R$ 12,0M"], ["G", "Zetti", 74, "R$ 3,2M"]],
  "Defensores": [["Z", "Aldair", 85, "R$ 9,4M"], ["Z", "Ricardo Rocha", 79, "R$ 5,1M"], ["L", "Jorginho", 82, "R$ 7,0M"], ["L", "Branco", 80, "R$ 6,2M"]],
  "Meias": [["M", "Dunga", 86, "R$ 10,0M"], ["M", "Raí", 84, "R$ 8,8M"], ["M", "Mauro Silva", 81, "R$ 6,6M"]],
  "Atacantes": [["A", "Romário", 92, "R$ 18,0M"], ["A", "Bebeto", 89, "R$ 14,5M"], ["A", "Careca", 83, "R$ 7,7M"]]
};
const TABS = ["Jogo", "Jogador", "Finanças", "Selecção"];
const MENUS = ["Treinador", "Jogo", "Campeonatos", "Mercado", "Clube", "Opções"];
function MenuBar({
  open,
  setOpen
}) {
  const dd = {
    Treinador: ["História", "Ranking", "Perfil", "Ofertas"],
    Jogo: ["Gravar na nuvem", "Calendário", "Continuar", "Sair"],
    Campeonatos: ["Classificação", "Minhas competições", "Melhores marcadores", "Últimos vencedores"],
    Mercado: ["Comprar jogador", "Leilão", "Vender jogador"],
    Clube: ["Estádio", "Finanças", "Renovar contrato"],
    Opções: ["Preferências", "Velocidade do jogo"]
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      display: "flex",
      borderBottom: "1px solid #000",
      position: "relative"
    }
  }, MENUS.map(m => /*#__PURE__*/React.createElement("div", {
    key: m,
    onClick: () => setOpen(open === m ? null : m),
    style: {
      padding: "5px 14px",
      fontWeight: 700,
      fontSize: 14,
      cursor: "pointer",
      position: "relative",
      color: open === m ? "#fff" : "#000",
      background: open === m ? "var(--navy)" : "transparent"
    }
  }, m, open === m && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "100%",
      left: 0,
      minWidth: 210,
      background: "#fff",
      border: "2px solid",
      borderColor: window.RF.bevelOut,
      zIndex: 30,
      boxShadow: "3px 3px 8px rgba(0,0,0,.4)",
      textAlign: "left"
    }
  }, dd[m].map((i, ix) => /*#__PURE__*/React.createElement("div", {
    key: ix,
    className: "dd-i",
    style: {
      padding: "5px 14px",
      fontSize: 15,
      fontWeight: 700,
      color: "#000",
      cursor: "pointer"
    }
  }, i))))));
}
function Roster({
  sel,
  setSel
}) {
  const [openG, setOpenG] = React.useState(Object.keys(ROSTER));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      color: "#000",
      border: "1px solid #000",
      maxHeight: 560,
      overflow: "auto"
    }
  }, Object.entries(ROSTER).map(([grp, rows], gi) => /*#__PURE__*/React.createElement("div", {
    key: grp,
    style: {
      borderBottom: "1px solid #000"
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => setOpenG(o => o.includes(grp) ? o.filter(x => x !== grp) : [...o, grp]),
    style: {
      background: "#e8e8e8",
      fontWeight: 800,
      fontSize: 13,
      padding: "5px 10px",
      borderBottom: "1px solid #000",
      display: "flex",
      justifyContent: "space-between",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("span", null, grp), /*#__PURE__*/React.createElement("span", null, openG.includes(grp) ? "▾" : "▸")), openG.includes(grp) && rows.map((r, ri) => {
    const starter = ["Taffarel", "Aldair", "Jorginho", "Branco", "Ricardo Rocha", "Dunga", "Raí", "Mauro Silva", "Romário", "Bebeto"].includes(r[1]);
    const active = sel === r[1];
    return /*#__PURE__*/React.createElement("div", {
      key: ri,
      onClick: () => setSel(r[1]),
      style: {
        display: "grid",
        gridTemplateColumns: "16px 22px 1fr 54px 66px",
        columnGap: 6,
        alignItems: "center",
        padding: "2px 8px",
        fontWeight: 700,
        fontSize: 14,
        cursor: "pointer",
        background: active ? "#000" : "transparent",
        color: active ? "#fff" : "#000"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        textAlign: "center"
      }
    }, starter ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: 16,
        height: 16,
        borderRadius: 4,
        fontSize: 10,
        fontWeight: 800,
        background: "#2e8b3d",
        color: "#fff"
      }
    }, "T") : ""), /*#__PURE__*/React.createElement("span", {
      style: {
        color: active ? "#fff" : "#555",
        fontWeight: 900
      }
    }, r[0]), /*#__PURE__*/React.createElement("span", null, r[1]), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--mono)"
      }
    }, r[2]), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--mono)",
        fontSize: 12,
        color: active ? "#cfe" : "#555"
      }
    }, r[3]));
  }))));
}
function MatchPanel({
  tab,
  setTab,
  sel,
  onJogar,
  onClassif
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: "#000",
      color: "#fff",
      padding: "12px 16px",
      display: "flex",
      flexDirection: "column",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      minHeight: 40,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#fff",
      fontSize: 15
    }
  }, "Pr\xF3ximo advers\xE1rio:"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 0,
      top: 0,
      fontWeight: 700,
      fontSize: 18
    }
  }, "2026"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--bluetxt)",
      fontWeight: 700,
      fontSize: 16,
      marginTop: 4
    }
  }, "Palmeiras"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--bluetxt)",
      fontSize: 15
    }
  }, "em casa \xB7 S\xE9rie A \xB7 rodada 14")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, tab === "Jogo" && /*#__PURE__*/React.createElement(PanelJogo, null), tab === "Jogador" && /*#__PURE__*/React.createElement(PanelJogador, {
    sel: sel
  }), tab === "Finanças" && /*#__PURE__*/React.createElement(PanelFin, null), tab === "Selecção" && /*#__PURE__*/React.createElement(PanelSel, null)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 0,
      borderTop: "1px solid #666",
      paddingTop: 6,
      marginTop: 8
    }
  }, TABS.map(t => /*#__PURE__*/React.createElement("div", {
    key: t,
    onClick: () => setTab(t),
    style: {
      padding: "3px 12px",
      fontSize: 14,
      cursor: "pointer",
      color: tab === t ? "#fff" : "#ccc",
      fontWeight: tab === t ? 700 : 400,
      border: "1px solid",
      borderColor: tab === t ? "#888 #888 #000 #888" : "transparent",
      background: tab === t ? "#111" : "transparent",
      borderBottom: tab === t ? "2px solid var(--yellow)" : "1px solid transparent"
    }
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      justifyContent: "flex-end",
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    icon: "\uD83D\uDCCA",
    size: "sm",
    onClick: onClassif
  }, "Classifica\xE7\xE3o"), /*#__PURE__*/React.createElement(Btn, {
    icon: "\u2714",
    variant: "ok",
    size: "big",
    onClick: onJogar
  }, "Jogar")));
}
function Bar({
  value,
  morale,
  max = 360
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 22,
      border: "2px solid",
      borderColor: window.RF.bevelField,
      marginTop: 6,
      maxWidth: max,
      position: "relative",
      overflow: "hidden",
      background: morale ? "var(--moral-grad)" : "var(--chrome)"
    }
  }, morale ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 0,
      right: 0,
      height: "100%",
      background: "var(--chrome)",
      width: `calc(100% - ${value}%)`
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      background: "var(--yellow)",
      width: `${value}%`
    }
  }));
}
function PanelJogo() {
  const scorers = [["Romário", 2], ["Bebeto", 1]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 6,
      fontWeight: 700
    }
  }, "Escala\xE7\xE3o prov\xE1vel"), scorers.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "space-between",
      margin: "2px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700
    }
  }, s[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--mono)"
    }
  }, "Forma ", 80 + i * 3))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15
    }
  }, "Moral do clube"), /*#__PURE__*/React.createElement(Bar, {
    value: 68,
    morale: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15
    }
  }, "Prepara\xE7\xE3o f\xEDsica"), /*#__PURE__*/React.createElement(Bar, {
    value: 82
  })));
}
function PanelJogador({
  sel
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--serif)",
      fontSize: 30,
      color: "#fff"
    }
  }, sel || "Romário"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      margin: "6px 0 16px"
    }
  }, "\uD83C\uDDE7\uD83C\uDDF7 Brasil \xB7 28 anos \xB7 Atacante"), [["Forma", 92], ["Moral", 84], ["Preço", "R$ 18,0M"], ["Contrato", "3 anos"], ["Gols na temporada", 21]].map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "space-between",
      maxWidth: 340,
      margin: "6px 0"
    }
  }, /*#__PURE__*/React.createElement("span", null, r[0]), /*#__PURE__*/React.createElement("b", {
    style: {
      fontFamily: typeof r[1] === "number" ? "var(--mono)" : "inherit"
    }
  }, r[1]))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20,
      display: "flex",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    icon: "\uD83D\uDCB0",
    variant: "ok",
    inline: true
  }, "Renovar"), /*#__PURE__*/React.createElement(Btn, {
    icon: "\uD83D\uDD28",
    inline: true
  }, "Vender por leil\xE3o")));
}
function PanelFin() {
  const rows = [["Bilheteria", "+ R$ 2,4M"], ["Patrocínio", "+ R$ 5,0M"], ["Salários", "− R$ 3,8M"], ["Manutenção", "− R$ 0,9M"]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      lineHeight: 1.35
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      marginBottom: 6
    }
  }, "Balan\xE7o da temporada"), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "space-between",
      maxWidth: 380,
      margin: "3px 0"
    }
  }, /*#__PURE__*/React.createElement("span", null, r[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--mono)",
      color: r[1].startsWith("+") ? "var(--ontext-lite3)" : "#ff9b9b"
    }
  }, r[1]))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      maxWidth: 380,
      marginTop: 10,
      fontSize: 20,
      fontWeight: 800
    }
  }, /*#__PURE__*/React.createElement("span", null, "Caixa"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--mono)",
      color: "var(--yellow)"
    }
  }, "R$ 24,7M")));
}
function PanelSel() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: "#aaa",
      marginBottom: 16
    }
  }, "T\xE1tica ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: "#fff"
    }
  }, "4-4-2"), " \xB7 onze ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: "#fff"
    }
  }, "11/11"), ".", /*#__PURE__*/React.createElement("br", null), "Titulares marcados com ", /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 16,
      height: 16,
      borderRadius: 4,
      fontSize: 10,
      fontWeight: 800,
      background: "#2e8b3d",
      color: "#fff"
    }
  }, "T"), " na lista."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap"
    }
  }, ["4-4-2", "4-3-3", "3-5-2", "5-3-2"].map((f, i) => /*#__PURE__*/React.createElement(Btn, {
    key: f,
    size: "sm",
    variant: i === 0 ? "ok" : "default",
    icon: i === 0 ? "✔" : undefined
  }, f))));
}
window.Hub = {
  MenuBar,
  Roster,
  MatchPanel
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game/hub.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game/overlays.jsx
try { (() => {
/* Overlays: live match, classification table, auction modal. */
const {
  Btn: OBtn
} = window.RF;
function stripe(a, b) {
  return {
    background: a,
    color: b
  };
}
function LiveMatch({
  onClose
}) {
  const games = [["Seu Clube", "Palmeiras", 2, 1, stripe("#c00", "#fff"), stripe("#093", "#fff")], ["Santos", "Corinthians", 0, 0, stripe("#111", "#fff"), stripe("#fff", "#000")], ["Flamengo", "Vasco", 3, 2, stripe("#c00", "#000"), stripe("#000", "#fff")], ["Grêmio", "Internacional", 1, 1, stripe("#04a", "#fff"), stripe("#c00", "#fff")]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "var(--felt)",
      zIndex: 60,
      overflow: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      color: "#fff",
      fontWeight: 800,
      textAlign: "center",
      padding: 6,
      fontSize: 15
    }
  }, "S\xE9rie A \u2014 Rodada 14"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      right: 36,
      top: 38,
      width: 56,
      height: 56,
      borderRadius: "50%",
      background: "conic-gradient(var(--navy) 62%, #fff 0)",
      border: "2px solid #fff",
      boxShadow: "0 2px 6px rgba(0,0,0,.4)",
      zIndex: 80
    }
  }), /*#__PURE__*/React.createElement("fieldset", {
    style: {
      margin: "56px 40px 0",
      border: "1px solid var(--navy)",
      padding: "10px 16px"
    }
  }, /*#__PURE__*/React.createElement("legend", {
    style: {
      color: "var(--yellow)",
      fontWeight: 800,
      fontSize: 16,
      padding: "2px 8px",
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/trofeu-serie-a.webp",
    style: {
      height: 20
    },
    alt: ""
  }), " S\xE9rie A"), games.map((g, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "66px 1fr 54px 1fr 160px",
      alignItems: "center",
      gap: 8,
      padding: "3px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--mono)",
      color: "var(--yellow)",
      fontSize: 14,
      textAlign: "right",
      fontWeight: 700
    }
  }, 78 + i * 3, "'"), /*#__PURE__*/React.createElement("span", {
    style: {
      ...g[4],
      padding: "5px 10px",
      fontWeight: 700,
      fontSize: 15,
      border: "1px solid rgba(255,255,255,.25)",
      textShadow: "0 1px 1px rgba(0,0,0,.4)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, g[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 12,
      justifyContent: "center",
      fontFamily: "var(--mono)",
      fontWeight: 800,
      fontSize: 16,
      color: "#fff"
    }
  }, g[2], /*#__PURE__*/React.createElement("span", null, "\xD7"), g[3]), /*#__PURE__*/React.createElement("span", {
    style: {
      ...g[5],
      padding: "5px 10px",
      fontWeight: 700,
      fontSize: 15,
      border: "1px solid rgba(255,255,255,.25)",
      textShadow: "0 1px 1px rgba(0,0,0,.4)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, g[1]), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--yellow)",
      fontSize: 14,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, i === 0 ? "⚽ Romário, Bebeto" : i === 2 ? "⚽ Edmundo x2" : "")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      gap: 12,
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(OBtn, {
    icon: "\u23E9",
    onClick: onClose
  }, "Acelerar"), /*#__PURE__*/React.createElement(OBtn, {
    icon: "\u2714",
    variant: "ok",
    size: "big",
    onClick: onClose
  }, "Fim de jogo")));
}
function Overlay({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(0,0,0,.35)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 50
    }
  }, children);
}
function Classification({
  onClose
}) {
  const rows = [[1, "Seu Clube", 29, 24, 60, "lib"], [2, "Palmeiras", 29, 22, 55, "lib"], [3, "São Paulo", 29, 20, 52, "lib"], [4, "Grêmio", 29, 18, 50, "lib"], [5, "Flamengo", 29, 16, 48, "sul"], [6, "Santos", 29, 14, 45, "sul"], [7, "Cruzeiro", 29, 12, 42, ""], [8, "Vasco", 29, 10, 40, ""]];
  return /*#__PURE__*/React.createElement(Overlay, null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      padding: 3,
      boxShadow: "var(--shadow-dlg)",
      width: 620
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      color: "#fff",
      fontWeight: 700,
      fontSize: 14,
      padding: "5px 8px",
      textAlign: "center"
    }
  }, "Classifica\xE7\xE3o \u2014 S\xE9rie A"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--chrome)",
      border: "2px solid",
      borderColor: window.RF.bevelOut,
      padding: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      maxHeight: "60vh",
      overflow: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "32px 1fr 40px 40px 50px 120px",
      padding: "4px 8px",
      fontSize: 13,
      fontWeight: 700,
      background: "#e0e0e0",
      position: "sticky",
      top: 0
    }
  }, /*#__PURE__*/React.createElement("span", null, "#"), /*#__PURE__*/React.createElement("span", null, "Equipa"), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: "center"
    }
  }, "J"), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: "center"
    }
  }, "SG"), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: "center"
    }
  }, "Pts"), /*#__PURE__*/React.createElement("span", null, "Zona")), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "32px 1fr 40px 40px 50px 120px",
      padding: "3px 8px",
      fontSize: 13,
      alignItems: "center",
      background: r[1] === "Seu Clube" ? "#fff7cc" : "transparent",
      borderLeft: r[5] === "lib" ? "4px solid var(--zone-lib-bar)" : r[5] === "sul" ? "4px solid var(--zone-sul-bar)" : "4px solid transparent"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: "center",
      fontWeight: r[1] === "Seu Clube" ? 800 : 400
    }
  }, r[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: r[1] === "Seu Clube" ? 800 : 700
    }
  }, r[1]), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: "center",
      fontFamily: "var(--mono)"
    }
  }, r[2]), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: "center",
      fontFamily: "var(--mono)"
    }
  }, r[3]), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: "center",
      fontFamily: "var(--mono)",
      fontWeight: 800
    }
  }, r[4]), /*#__PURE__*/React.createElement("span", null, r[5] === "lib" && /*#__PURE__*/React.createElement("em", {
    style: {
      fontStyle: "normal",
      background: "var(--zone-lib-bg)",
      color: "var(--zone-lib-fg)",
      fontSize: 10,
      fontWeight: 800,
      padding: "2px 5px",
      borderRadius: 3
    }
  }, "Libertadores"), r[5] === "sul" && /*#__PURE__*/React.createElement("em", {
    style: {
      fontStyle: "normal",
      background: "var(--zone-sul-bg)",
      color: "var(--zone-sul-fg)",
      fontSize: 10,
      fontWeight: 800,
      padding: "2px 5px",
      borderRadius: 3
    }
  }, "Sul-Americana"))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(OBtn, {
    icon: "\u2714",
    variant: "ok",
    onClick: onClose
  }, "OK")))));
}
function Auction({
  onClose
}) {
  return /*#__PURE__*/React.createElement(Overlay, null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      padding: 3,
      boxShadow: "var(--shadow-dlg)",
      width: 480,
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: -16,
      left: 14,
      zIndex: 3,
      display: "flex",
      alignItems: "center",
      gap: 7,
      background: "#fff",
      border: "2px solid",
      borderColor: window.RF.bevelOut,
      borderRadius: 12,
      padding: "5px 12px 5px 5px",
      boxShadow: "var(--shadow-badge)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/trofeu-libertadores.webp",
    style: {
      width: 30,
      height: 30,
      objectFit: "contain"
    },
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 800,
      fontSize: 13,
      color: "#111"
    }
  }, "Leil\xE3o de jogadores")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      color: "#fff",
      fontWeight: 700,
      fontSize: 14,
      padding: "5px 8px",
      textAlign: "center"
    }
  }, "Leil\xE3o de jogadores"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--body-yellow)",
      padding: "24px 22px 18px",
      color: "#000"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      alignItems: "center",
      fontSize: 15,
      margin: "4px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 120
    }
  }, "Jogador"), /*#__PURE__*/React.createElement("b", null, "Ed\xEDlson (A) \xB7 Forma 84")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      alignItems: "center",
      fontSize: 15,
      margin: "4px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 120
    }
  }, "Lance atual"), /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: 22,
      fontFamily: "var(--mono)",
      color: "var(--success)"
    }
  }, "R$ 6.800.000")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      alignItems: "center",
      fontSize: 15,
      margin: "4px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 120
    }
  }, "Maior lance"), /*#__PURE__*/React.createElement("span", {
    style: {
      background: "#c00",
      color: "#fff",
      padding: "2px 12px",
      fontWeight: 800,
      textShadow: "0 1px 2px rgba(0,0,0,.5)"
    }
  }, "Flamengo")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      justifyContent: "flex-end",
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(OBtn, {
    icon: "\u2716",
    variant: "cancel",
    onClick: onClose
  }, "Desistir"), /*#__PURE__*/React.createElement(OBtn, {
    icon: "\uD83D\uDD28",
    variant: "ok",
    size: "big",
    onClick: onClose
  }, "Cobrir lance")))));
}
window.Overlays = {
  LiveMatch,
  Classification,
  Auction
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game/overlays.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game/screens.jsx
try { (() => {
/* RetroFoot98 game UI kit — self-contained recreation using design tokens.
   Mirrors the real production classes (.cl-*) with inline styles so the kit
   renders standalone. Primitives here match components/ 1:1. */

const bevelOut = "var(--bevL) var(--bevD2) var(--bevD2) var(--bevL)";
const bevelIn = "var(--bevD2) var(--bevL) var(--bevL) var(--bevD2)";
const bevelField = "var(--bevD) var(--bevL) var(--bevL) var(--bevD)";

// ---------- primitives ----------
function Btn({
  icon,
  children,
  variant = "default",
  size = "md",
  inline,
  disabled,
  onClick,
  style = {}
}) {
  const [p, setP] = React.useState(false);
  const S = {
    sm: {
      pad: "5px 9px",
      mh: 28,
      fs: 11,
      ic: 13
    },
    md: {
      pad: "8px 14px",
      mh: 46,
      fs: 13,
      ic: 20
    },
    big: {
      pad: "14px 18px",
      mh: 56,
      fs: 13,
      ic: 26
    },
    wide: {
      pad: "18px 34px",
      mh: 56,
      fs: 15,
      ic: 20
    }
  }[size];
  const online = variant === "online";
  return /*#__PURE__*/React.createElement("button", {
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseDown: () => setP(true),
    onMouseUp: () => setP(false),
    onMouseLeave: () => setP(false),
    style: {
      fontFamily: "var(--sans)",
      fontSize: S.fs,
      fontWeight: online || size === "wide" ? 800 : 400,
      background: online ? "var(--success)" : "var(--chrome)",
      color: online ? "#fff" : disabled ? "var(--bevD)" : "#000",
      border: "2px solid",
      borderColor: online ? "var(--success-lite) var(--success-deep) var(--success-deep) var(--success-lite)" : p && !disabled ? bevelIn : bevelOut,
      padding: S.pad,
      minHeight: S.mh,
      minWidth: 70,
      cursor: disabled ? "default" : "pointer",
      display: "inline-flex",
      flexDirection: inline ? "row" : "column",
      alignItems: "center",
      justifyContent: "center",
      gap: inline ? 8 : 3,
      boxSizing: "border-box",
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: inline ? S.fs + 4 : S.ic,
      lineHeight: 1,
      opacity: disabled ? .4 : 1,
      color: variant === "ok" ? "var(--success-alt)" : variant === "cancel" ? "var(--danger)" : "inherit"
    }
  }, icon), children && /*#__PURE__*/React.createElement("span", null, children));
}
function TopBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "linear-gradient(#d8d8d8,#c0c0c0)",
      borderBottom: "1px solid #808080",
      height: 26,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 6,
      fontWeight: 700,
      fontSize: 13,
      color: "#000",
      position: "sticky",
      top: 0,
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.webp",
    style: {
      width: 18,
      height: 18,
      objectFit: "contain"
    },
    alt: ""
  }), "RetroFoot98 \u2014 100% Online");
}

// ---------- landing (Acerca) ----------
function Landing({
  onEnter
}) {
  const badges = [{
    img: "badge-clubes",
    t: "Clubes reais"
  }, {
    img: "badge-liga",
    t: "Liga com amigos"
  }, {
    img: "badge-chat",
    t: "Chat em tempo real"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.webp",
    style: {
      width: 140,
      height: 140,
      objectFit: "contain",
      filter: "var(--shadow-logo)"
    },
    alt: "RetroFoot98"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      padding: 3,
      boxShadow: "var(--shadow-dlg)",
      width: "min(560px,92vw)",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      color: "#fff",
      fontWeight: 700,
      fontSize: 14,
      padding: "5px 8px",
      textAlign: "center"
    }
  }, "Acerca"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "30px 20px 22px",
      background: "var(--felt)",
      position: "relative",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 14,
      top: 8,
      color: "var(--yellow)",
      fontSize: 12
    }
  }, "v2.4"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 14,
      top: 8,
      background: "var(--success)",
      color: "#fff",
      fontWeight: 800,
      fontSize: 13,
      padding: "4px 12px",
      borderRadius: 99,
      border: "1px solid var(--success-deep)",
      whiteSpace: "nowrap"
    }
  }, "\uD83D\uDFE2 100% Online"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--ontext-lite)",
      fontWeight: 600,
      fontSize: 15,
      margin: "6px 0 20px"
    }
  }, "Voc\xEA \xE9 o t\xE9cnico. Escale o time, negocie jogadores e leve o clube da S\xE9rie D ao topo."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 16,
      justifyContent: "center",
      marginBottom: 22
    }
  }, badges.map(b => /*#__PURE__*/React.createElement("div", {
    key: b.img,
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: `../../assets/${b.img}.webp`,
    style: {
      width: 96,
      height: 96,
      objectFit: "contain",
      filter: "drop-shadow(0 4px 8px rgba(0,0,0,.35))"
    },
    alt: ""
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--yellow)",
      fontSize: 12,
      fontWeight: 700,
      marginTop: 4
    }
  }, b.t)))), /*#__PURE__*/React.createElement(Btn, {
    icon: "\u26BD",
    size: "wide",
    onClick: onEnter
  }, "Entrar"))));
}

// ---------- mode choice ----------
function ModeChoice({
  onPick
}) {
  const [hover, setHover] = React.useState(null);
  const cards = [{
    id: "solo",
    ic: "⚽",
    t: "Solo",
    d: "Você contra a máquina. Comece uma nova carreira quando quiser."
  }, {
    id: "res",
    ic: "💬",
    t: "Modo Resenha",
    d: "Liga online com a galera, com chat em tempo real durante a rodada."
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      padding: 3,
      boxShadow: "var(--shadow-dlg)",
      width: "min(620px,94vw)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--navy)",
      color: "#fff",
      fontWeight: 700,
      fontSize: 14,
      padding: "5px 8px",
      textAlign: "center"
    }
  }, "RetroFoot98"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "26px 20px",
      background: "var(--felt)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: "#fff",
      fontWeight: 700,
      fontSize: 16,
      textAlign: "center",
      marginBottom: 22
    }
  }, "Como voc\xEA quer jogar?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 20,
      justifyContent: "center"
    }
  }, cards.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    onClick: () => onPick(c.id),
    onMouseEnter: () => setHover(c.id),
    onMouseLeave: () => setHover(null),
    style: {
      width: 260,
      background: hover === c.id ? "rgba(255,255,255,.22)" : "rgba(255,255,255,.1)",
      border: "2px solid",
      borderColor: hover === c.id ? "var(--yellow)" : "rgba(255,255,255,.35)",
      borderRadius: 12,
      padding: "22px 18px",
      textAlign: "center",
      cursor: "pointer",
      transition: "background .15s"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 40,
      marginBottom: 10
    }
  }, c.ic), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--yellow)",
      fontWeight: 800,
      fontSize: 18,
      marginBottom: 8
    }
  }, c.t), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--ontext-lite)",
      fontSize: 13,
      lineHeight: 1.4
    }
  }, c.d))))));
}
window.RF = {
  Btn,
  TopBar,
  Landing,
  ModeChoice,
  bevelOut,
  bevelIn,
  bevelField
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.TabButton = __ds_scope.TabButton;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.ChoiceCard = __ds_scope.ChoiceCard;

__ds_ns.StatBar = __ds_scope.StatBar;

__ds_ns.TeamStripe = __ds_scope.TeamStripe;

__ds_ns.ZoneTag = __ds_scope.ZoneTag;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.MoneyField = __ds_scope.MoneyField;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.SpinField = __ds_scope.SpinField;

__ds_ns.Fieldset = __ds_scope.Fieldset;

__ds_ns.Window = __ds_scope.Window;

__ds_ns.WindowBadge = __ds_scope.WindowBadge;

})();
